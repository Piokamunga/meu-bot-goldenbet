print('Iniciando goldenbetbot...')
import bot
